const modal = document.getElementById('sponsor-modal');
const donateLink = document.getElementById('donate-link');
let amount = '35';

document.querySelectorAll('.open-sponsor').forEach(button => button.addEventListener('click', () => {
  modal.classList.add('open');
  modal.setAttribute('aria-hidden', 'false');
}));

function closeModal() {
  modal.classList.remove('open');
  modal.setAttribute('aria-hidden', 'true');
}
document.querySelector('.modal-close').addEventListener('click', closeModal);
modal.addEventListener('click', event => { if (event.target === modal) closeModal(); });
document.addEventListener('keydown', event => { if (event.key === 'Escape') closeModal(); });

document.querySelectorAll('.donation-options button').forEach(option => option.addEventListener('click', () => {
  document.querySelectorAll('.donation-options button').forEach(button => button.classList.remove('selected'));
  option.classList.add('selected');
  amount = option.dataset.amount;
  donateLink.textContent = `Continue with $${amount}/month →`;
  donateLink.href = `mailto:hello@goldenagesociety.org?subject=I%20would%20like%20to%20sponsor%20GAS%20with%20%24${amount}%20per%20month`;
}));

const menu = document.querySelector('.menu-button');
const nav = document.querySelector('.nav-links');
menu.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  menu.setAttribute('aria-expanded', open);
  menu.textContent = open ? '×' : '☰';
});
nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open'); menu.setAttribute('aria-expanded', 'false'); menu.textContent = '☰';
}));

const slides = [...document.querySelectorAll('.slide')];
const slideDots = [...document.querySelectorAll('.slide-dots button')];
let slideIndex = 0;
let slideTimer;

function showSlide(index) {
  slideIndex = (index + slides.length) % slides.length;
  slides.forEach((slide, i) => {
    const active = i === slideIndex;
    slide.classList.toggle('is-active', active);
    slide.setAttribute('aria-hidden', String(!active));
  });
  slideDots.forEach((dot, i) => dot.classList.toggle('is-active', i === slideIndex));
}
function resetSlideTimer() {
  clearInterval(slideTimer);
  slideTimer = setInterval(() => showSlide(slideIndex + 1), 6500);
}
document.querySelector('.previous-slide').addEventListener('click', () => { showSlide(slideIndex - 1); resetSlideTimer(); });
document.querySelector('.next-slide').addEventListener('click', () => { showSlide(slideIndex + 1); resetSlideTimer(); });
slideDots.forEach((dot, i) => dot.addEventListener('click', () => { showSlide(i); resetSlideTimer(); }));
resetSlideTimer();
